window.consoleLogger = {
    log: function (message) {
        console.log(message);
    },
    warn: function (message) {
        console.warn(message);
    },
    error: function (message) {
        console.error(message);
    }
};
